# P4_Singapore_MIR — Submission Package

**Target journal:** Management International Review (MIR)
**Build date:** 2026-05-21
**Status:** ✅ Ready for blind-review submission

## Files in this package

| File | Format | Purpose |
|---|---|---|
| `P4_Singapore_MIR_manuscript_EN.docx` | DOCX | Primary submission file (most journals require this) |
| `P4_Singapore_MIR_manuscript_EN.pdf` | PDF | Preview / reference copy |
| `P4_Singapore_MIR_manuscript_EN.tex` | LaTeX | Source for journals that accept LaTeX |
| `P4_Singapore_MIR_manuscript_VN.docx` | DOCX | Vietnamese version for CTU thesis dossier |
| `P4_Singapore_MIR_manuscript_VN.pdf` | PDF | Vietnamese preview |
| `COVER_LETTER_TEMPLATE.md` | Markdown | Cover letter to fill in before submission |

## Compliance checklist

- [x] Blind review: no author names in body or filename
- [x] APA 7th references with DOI links where available
- [x] JEL Classification codes provided
- [x] Keywords (5-7 terms) provided
- [x] Abstract follows 5-component IMRaD structure (Purpose / Design / Findings / Originality)
- [x] No symbols (§, ¶, arrows) in prose; tables use standard markdown
- [x] Em-dashes humanised to comma/colon equivalents where appropriate
- [x] No NotebookLM or other non-academic citations
- [x] All inline citations have references entries (and vice versa)
- [x] Figures embedded in DOCX and referenced from PDF
- [x] Tables formatted per APA 7th (top + bottom rules only)

## Pre-submission user actions

1. Open the DOCX and confirm title page, abstract, and references render correctly.
2. Fill in `COVER_LETTER_TEMPLATE.md` with your name, institution, and the date.
3. Upload to the journal's submission portal:
   - **Management International Review (MIR)**: see journal's submission guidelines page.

